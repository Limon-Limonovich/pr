﻿using System;

namespace DeliveryCalculator
{
    public static class TariffService
    {
        public static decimal Calculate(
            decimal weight, int distance, bool express)
        {
            if (weight <= 0 || weight > 30)
                throw new ArgumentException(
                    "Масса должна быть больше 0 и не больше 30 кг.");
            if (decimal.Round(weight, 2) != weight)
                throw new ArgumentException(
                    "Масса должна содержать не более 2 знаков после запятой.");
            if (distance < 1 || distance > 1000)
                throw new ArgumentException(
                    "Расстояние должно быть от 1 до 1000 км.");

            decimal cost = 200m + 40m * weight + 5m * distance;
            if (express) cost *= 1.5m;
            return Math.Round(cost, 2, MidpointRounding.AwayFromZero);
        }
    }
}
