﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace DeliveryCalculator
{
    public sealed class MainForm : Form
    {
        private readonly NumericUpDown weight = new NumericUpDown();
        private readonly NumericUpDown distance = new NumericUpDown();
        private readonly CheckBox express = new CheckBox();
        private readonly Label result = new Label();

        public MainForm()
        {
            Text = "ПР5 — Расчёт стоимости доставки";
            ClientSize = new Size(530, 330);
            Font = new Font("Segoe UI", 11);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Controls.Add(new Label { Text = "Масса, кг", Left = 25,
                Top = 30, AutoSize = true });
            weight.SetBounds(265, 25, 220, 32);
            weight.DecimalPlaces = 2;
            weight.Minimum = -1; weight.Maximum = 100;
            weight.Value = 2; weight.Increment = 0.1m;
            Controls.Add(weight);
            Controls.Add(new Label { Text = "Расстояние, км", Left = 25,
                Top = 80, AutoSize = true });
            distance.SetBounds(265, 75, 220, 32);
            distance.Minimum = -1; distance.Maximum = 1001;
            distance.Value = 10;
            Controls.Add(distance);
            express.Text = "Срочная доставка";
            express.SetBounds(25, 125, 300, 35);
            Controls.Add(express);
            var button = new Button { Text = "Рассчитать" };
            button.SetBounds(25, 175, 460, 40);
            button.Click += CalculateClick;
            Controls.Add(button);
            result.SetBounds(25, 235, 475, 75);
            result.Text = "Введите данные и нажмите Рассчитать";
            Controls.Add(result);
            // После изменения ввода старый результат не показывается.
            weight.ValueChanged += ClearResult;
            distance.ValueChanged += ClearResult;
            express.CheckedChanged += ClearResult;
        }

        private void ClearResult(object sender, EventArgs e)
        {
            result.ForeColor = SystemColors.ControlText;
            result.Text = "Параметры изменены. Нажмите Рассчитать";
        }

        private void CalculateClick(object sender, EventArgs e)
        {
            try
            {
                decimal cost = TariffService.Calculate(weight.Value,
                    Decimal.ToInt32(distance.Value), express.Checked);
                result.ForeColor = Color.DarkGreen;
                result.Text = "Стоимость: " + cost.ToString("F2",
                    CultureInfo.GetCultureInfo("ru-RU")) + " руб.";
            }
            catch (ArgumentException ex)
            {
                result.ForeColor = Color.DarkRed;
                result.Text = ex.Message;
            }
        }
    }
}
